$(document).ready(function () {
// wowslider
$("#wowslider-container1").wowSlider({effect:"shift",prev:"",next:"",duration:8*100,delay:20*100,width:533,height:360,autoPlay:true,autoPlayVideo:false,playPause:true,stopOnHover:false,loop:false,bullets:1,caption:true,captionEffect:"parallax",controls:true,controlsThumb:false,responsive:1,fullScreen:false,gestures:2,onBeforeStep:0,images:0});
});